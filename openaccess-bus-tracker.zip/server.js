const http = require('http');
const fs = require('fs');
const path = require('path');

// --- CONSTANTS ---
const PORT = process.env.PORT || 3001;
const DB_FILE = path.join(__dirname, 'bus_tracker_db.json');
const DIST_DIR = path.join(__dirname, 'dist');

// --- PERSISTENCE LAYER ---
const INITIAL_DATA = {
  buses: [
    {
      id: '1',
      busNumber: 'BUS-101',
      driverName: 'John Doe',
      routeStart: 'Campus Main',
      routeEnd: 'Downtown Station',
      currentStop: 'Library Corner',
      lastPassedStop: 'Engineering Dept',
      status: 'Running',
      lastUpdated: new Date().toISOString(),
      stops: [
        { id: 's1', name: 'Campus Main', order: 1 },
        { id: 's2', name: 'Engineering Dept', order: 2 },
        { id: 's3', name: 'Library Corner', order: 3 },
        { id: 's4', name: 'Downtown Station', order: 4 },
      ]
    }
  ],
  users: [
    { id: 'u1', name: 'admin', role: 'ADMIN', joinedAt: new Date().toISOString() },
    { id: 'u2', name: 'John Doe', role: 'DRIVER', joinedAt: new Date().toISOString() },
    { id: 'u3', name: 'Alice Student', role: 'STUDENT', joinedAt: new Date().toISOString() },
  ],
  adminCredentials: { name: 'admin', password: 'admin' }
};

// Load DB from disk or initialize
let db = { ...INITIAL_DATA };
if (fs.existsSync(DB_FILE)) {
  try {
    const fileData = fs.readFileSync(DB_FILE, 'utf8');
    db = JSON.parse(fileData);
    console.log('Database loaded from disk.');
  } catch (err) {
    console.error('Failed to load database, using initial data.');
  }
}

// Helper to save DB
const saveDb = () => {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error('Failed to save database:', err);
  }
};

// --- STATIC FILE SERVING HELPERS ---
const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

// Serve a static file from DIST_DIR
const serveStaticFile = (res, filePath) => {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        // Fallback to index.html for SPA routing (React Router support)
        fs.readFile(path.join(DIST_DIR, 'index.html'), (err2, content2) => {
            if (err2) {
                // If dist/index.html doesn't exist, the user hasn't built the app
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end('Error: Frontend build missing. Please run "npm run build" first.');
            } else {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end(content2, 'utf-8');
            }
        });
      } else {
        res.writeHead(500);
        res.end(`Server Error: ${err.code}`);
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
};

// --- SERVER ---
const server = http.createServer((req, res) => {
  // CORS Headers - Allow access from any origin (Mobile/Ngrok/Localhost)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET, POST, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Handle Preflight requests
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = req.url.split('?')[0]; // Ignore query params

  // API ROUTE: GET DATA
  if (url === '/api/data' && req.method === 'GET') {
    res.writeHead(200, { 
        'Content-Type': 'application/json',
        // Prevent caching so all devices get real-time updates
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate'
    });
    res.end(JSON.stringify(db));
    return;
  }

  // API ROUTE: UPDATE DATA
  if (url === '/api/update' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      try {
        const updates = JSON.parse(body);
        if (updates.buses) db.buses = updates.buses;
        if (updates.users) db.users = updates.users;
        if (updates.adminCredentials) db.adminCredentials = updates.adminCredentials;
        
        saveDb(); // Persist to disk
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON' }));
      }
    });
    return;
  }

  // STATIC FILE ROUTE
  // If not an API route, serve the frontend
  let filePath = path.join(DIST_DIR, url === '/' ? 'index.html' : url);
  serveStaticFile(res, filePath);
});

// Bind to 0.0.0.0 to allow connections from external IPs (Mobile/Wi-Fi)
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n=== OPEN ACCESS BUS TRACKER SERVER ===`);
  console.log(`1. Server running on port ${PORT}`);
  console.log(`2. To access locally: http://localhost:${PORT}`);
  console.log(`3. To access publicly:  Use 'npx ngrok http ${PORT}'`);
  console.log(`   (Ensure you have run 'npm run build' first)`);
});