import React, { useState, useEffect } from 'react';
import { SystemProvider, useSystem } from './context/SystemContext';
import Layout from './components/Layout';
import RoleSelection from './views/RoleSelection';
import AdminDashboard from './views/AdminDashboard';
import DriverDashboard from './views/DriverDashboard';
import StudentDashboard from './views/StudentDashboard';
import { Role } from './types';

// Child component to consume the context
const AppContent: React.FC = () => {
  const { currentUser } = useSystem();
  const [currentRole, setCurrentRole] = useState<Role>(null);

  // Effect to sync local component state with the persisted user session
  // This ensures that if the page is refreshed, the user stays logged in
  useEffect(() => {
    if (currentUser) {
      setCurrentRole(currentUser.role);
    } else {
      setCurrentRole(null);
    }
  }, [currentUser]);

  const renderContent = () => {
    switch (currentRole) {
      case 'ADMIN':
        return <AdminDashboard />;
      case 'DRIVER':
        return <DriverDashboard />;
      case 'STUDENT':
        return <StudentDashboard />;
      default:
        // Pass the setter so RoleSelection can trigger the view change
        // typically RoleSelection calls login() in context, which triggers the useEffect above
        return <RoleSelection onSelectRole={setCurrentRole} />;
    }
  };

  return (
    <Layout 
      currentRole={currentRole} 
      onLogout={() => setCurrentRole(null)}
    >
      {renderContent()}
    </Layout>
  );
};

// Main App component wraps the content in the Provider
const App: React.FC = () => {
  return (
    <SystemProvider>
      <AppContent />
    </SystemProvider>
  );
};

export default App;