import React, { useState } from 'react';
import { useSystem } from '../context/SystemContext';
import { Search, MapPin, Navigation, Clock, RefreshCw, ArrowRight } from 'lucide-react';
import { BusStatus } from '../types';

const StudentDashboard: React.FC = () => {
  const { buses } = useSystem();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredBuses = buses.filter(bus => 
    bus.busNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
    bus.routeStart.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bus.routeEnd.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: BusStatus) => {
    const styles = {
      'Running': 'bg-emerald-400/10 text-emerald-600 border-emerald-200 shadow-[0_0_15px_rgba(16,185,129,0.2)]',
      'Delayed': 'bg-rose-400/10 text-rose-600 border-rose-200 shadow-[0_0_15px_rgba(244,63,94,0.2)]',
      'Reached': 'bg-blue-400/10 text-blue-600 border-blue-200 shadow-[0_0_15px_rgba(59,130,246,0.2)]',
      'Maintenance': 'bg-slate-400/10 text-slate-600 border-slate-200'
    };
    return (
      <span className={`px-3 py-1 md:px-4 md:py-1.5 rounded-lg text-[10px] md:text-xs font-black uppercase tracking-widest border backdrop-blur-md ${styles[status] || styles['Maintenance']}`}>
        {status}
      </span>
    );
  };

  const calculateNextStop = (bus: any) => {
    if (!bus.stops || bus.stops.length === 0) return "Not Scheduled";
    const currentIndex = bus.stops.findIndex((s: any) => s.name === bus.currentStop);
    
    if (currentIndex === -1) {
        return bus.stops[0]?.name || "Unknown";
    }
    
    if (currentIndex < bus.stops.length - 1) {
        return bus.stops[currentIndex + 1].name;
    }
    
    return "End of Line";
  };

  return (
    <div className="max-w-6xl mx-auto py-4">
      <div className="mb-8 md:mb-12 text-center space-y-2 md:space-y-4 px-4">
        <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-700 to-violet-600 text-glow-blue tracking-tighter">
          Find Your Ride
        </h2>
        <p className="text-base md:text-xl text-slate-500 font-medium max-w-2xl mx-auto">
          Real-time tracking for the entire campus fleet.
        </p>
      </div>

      <div className="relative max-w-2xl mx-auto mb-10 md:mb-16 group px-4">
        <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-violet-400 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
        <div className="relative bg-white rounded-2xl shadow-xl flex items-center p-2">
            <div className="pl-4 text-slate-400">
                <Search className="h-5 w-5 md:h-6 md:w-6" />
            </div>
            <input 
                type="text" 
                placeholder="Search Bus # or Location..."
                className="block w-full pl-3 md:pl-4 pr-4 md:pr-12 py-3 md:py-4 rounded-xl text-lg md:text-xl font-bold bg-transparent border-none focus:ring-0 placeholder:text-slate-300 text-slate-800"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
        </div>
      </div>

      <div className="grid gap-6 md:gap-8 md:grid-cols-2 lg:grid-cols-2">
        {filteredBuses.length > 0 ? (
            filteredBuses.map(bus => (
                <div key={bus.id} className="glass-panel rounded-3xl p-0 hover:shadow-2xl hover:shadow-blue-200/40 hover:-translate-y-1 transition-all duration-300 group border border-white/60">
                    
                    {/* Card Header */}
                    <div className="bg-gradient-to-r from-slate-50/80 to-white/50 p-6 border-b border-slate-100 flex justify-between items-center backdrop-blur-sm rounded-t-3xl">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-white shadow-sm flex items-center justify-center text-xl md:text-2xl font-black text-slate-800 group-hover:text-blue-600 transition-colors">
                                {bus.busNumber.split('-')[1] || 'BUS'}
                            </div>
                            <div>
                                <h3 className="text-base md:text-lg font-bold text-slate-800">{bus.busNumber}</h3>
                                <p className="text-[10px] md:text-xs font-bold text-slate-400 uppercase tracking-widest">Active Service</p>
                            </div>
                        </div>
                        {getStatusBadge(bus.status)}
                    </div>

                    {/* Card Body */}
                    <div className="p-6 md:p-8 space-y-6 md:space-y-8">
                        {/* Route Info */}
                        <div className="flex items-center gap-4 bg-blue-50/50 p-4 rounded-2xl border border-blue-100/50">
                            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 text-blue-600">
                                <Navigation className="w-5 h-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="text-xs font-bold text-blue-400 uppercase tracking-widest mb-1">Route</p>
                                <div className="flex items-center gap-2 text-slate-700 font-bold text-base md:text-lg truncate">
                                    <span className="truncate">{bus.routeStart}</span> 
                                    <ArrowRight className="w-4 h-4 text-slate-300 flex-shrink-0" /> 
                                    <span className="truncate">{bus.routeEnd}</span>
                                </div>
                            </div>
                        </div>

                        {/* Location Grid */}
                        <div className="grid grid-cols-2 gap-4 md:gap-6">
                            <div>
                                <div className="flex items-center gap-2 mb-2 text-emerald-600">
                                    <MapPin className="w-4 h-4 md:w-5 md:h-5" />
                                    <span className="text-[10px] md:text-xs font-black uppercase tracking-widest">Current Stop</span>
                                </div>
                                <p className="text-lg md:text-xl font-extrabold text-slate-800 leading-tight group-hover:text-emerald-700 transition-colors break-words">{bus.currentStop}</p>
                            </div>
                            <div className="border-l border-slate-100 pl-4 md:pl-6">
                                <div className="flex items-center gap-2 mb-2 text-slate-400">
                                    <Clock className="w-4 h-4 md:w-5 md:h-5" />
                                    <span className="text-[10px] md:text-xs font-black uppercase tracking-widest">Passed</span>
                                </div>
                                <p className="text-base md:text-lg font-semibold text-slate-500 leading-tight break-words">{bus.lastPassedStop}</p>
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
                            <div className="flex flex-col max-w-[60%]">
                                <span className="text-[10px] md:text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Up Next</span>
                                <span className="text-sm md:text-base font-bold text-indigo-600 truncate">{calculateNextStop(bus)}</span>
                            </div>
                            <div className="text-right">
                                <div className="inline-flex items-center gap-2 px-2 py-1 md:px-3 md:py-1 bg-slate-50 rounded-lg border border-slate-100">
                                    <RefreshCw className="w-3 h-3 text-slate-400 animate-spin-slow" />
                                    <span className="text-[10px] md:text-xs font-mono font-bold text-slate-500">
                                        {new Date(bus.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ))
        ) : (
            <div className="col-span-full py-20 text-center glass-panel rounded-3xl border-2 border-dashed border-slate-200">
                <p className="text-xl md:text-2xl font-bold text-slate-300">No vehicles match your criteria.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;