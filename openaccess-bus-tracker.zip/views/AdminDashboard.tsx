import React, { useState } from 'react';
import { useSystem } from '../context/SystemContext';
import { Trash2, PlusCircle, Users, BusFront, Clock, ArrowRight, Settings, Lock, CheckCircle } from 'lucide-react';
import { BusStatus } from '../types';

const AdminDashboard: React.FC = () => {
  const { buses, users, addBus, deleteBus, addUser, deleteUser, adminCredentials, updateAdminCredentials } = useSystem();
  const [activeTab, setActiveTab] = useState<'BUSES' | 'USERS' | 'SETTINGS'>('BUSES');

  // Form States
  const [newBusNum, setNewBusNum] = useState('');
  const [newBusDriver, setNewBusDriver] = useState('');
  const [newBusStart, setNewBusStart] = useState('');
  const [newBusEnd, setNewBusEnd] = useState('');

  const [newUserName, setNewUserName] = useState('');
  const [newUserRole, setNewUserRole] = useState<'DRIVER' | 'STUDENT'>('STUDENT');

  // Settings State
  const [adminName, setAdminName] = useState(adminCredentials.name);
  const [adminPass, setAdminPass] = useState(adminCredentials.password);
  const [settingsMsg, setSettingsMsg] = useState('');

  const handleAddBus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBusNum || !newBusDriver) return;
    addBus({
      busNumber: newBusNum,
      driverName: newBusDriver,
      routeStart: newBusStart || 'Main Depot',
      routeEnd: newBusEnd || 'Loop',
      currentStop: 'Depot',
      lastPassedStop: 'N/A',
      status: 'Running',
      stops: []
    });
    setNewBusNum('');
    setNewBusDriver('');
    setNewBusStart('');
    setNewBusEnd('');
  };

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName) return;
    addUser({
      name: newUserName,
      role: newUserRole
    });
    setNewUserName('');
  };

  const handleUpdateSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateAdminCredentials(adminName, adminPass);
    setSettingsMsg('Credentials updated successfully!');
    setTimeout(() => setSettingsMsg(''), 3000);
  };

  const getStatusColor = (status: BusStatus) => {
    switch(status) {
      case 'Running': return 'bg-emerald-100/50 text-emerald-700 border-emerald-200';
      case 'Delayed': return 'bg-rose-100/50 text-rose-700 border-rose-200';
      case 'Reached': return 'bg-blue-100/50 text-blue-700 border-blue-200';
      default: return 'bg-slate-100/50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-500">
      
      {/* Dashboard Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-200/60">
        <div>
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800 tracking-tight mb-1">System Overview</h2>
          <p className="text-base md:text-lg text-slate-500 font-medium">Manage fleet operations and user access.</p>
        </div>
        
        {/* Mobile Scrollable Tabs */}
        <div className="w-full md:w-auto overflow-x-auto pb-2 md:pb-0 -mx-4 md:mx-0 px-4 md:px-0 scrollbar-hide">
            <div className="glass-panel p-1.5 rounded-xl flex gap-2 shadow-sm min-w-max">
                <button 
                    type="button"
                    onClick={() => setActiveTab('BUSES')}
                    className={`px-4 py-3 rounded-lg font-bold text-sm transition-all duration-300 flex items-center gap-2 cursor-pointer touch-manipulation ${activeTab === 'BUSES' ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/30' : 'text-slate-500 hover:bg-slate-100'}`}
                >
                    <BusFront className="w-4 h-4" /> FLEET
                </button>
                <button 
                    type="button"
                    onClick={() => setActiveTab('USERS')}
                    className={`px-4 py-3 rounded-lg font-bold text-sm transition-all duration-300 flex items-center gap-2 cursor-pointer touch-manipulation ${activeTab === 'USERS' ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/30' : 'text-slate-500 hover:bg-slate-100'}`}
                >
                    <Users className="w-4 h-4" /> USERS
                </button>
                <button 
                    type="button"
                    onClick={() => setActiveTab('SETTINGS')}
                    className={`px-4 py-3 rounded-lg font-bold text-sm transition-all duration-300 flex items-center gap-2 cursor-pointer touch-manipulation ${activeTab === 'SETTINGS' ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/30' : 'text-slate-500 hover:bg-slate-100'}`}
                >
                    <Settings className="w-4 h-4" /> SETTINGS
                </button>
            </div>
        </div>
      </div>

      {activeTab === 'BUSES' && (
        <div className="grid xl:grid-cols-12 gap-8">
          {/* Add Bus Form */}
          <div className="xl:col-span-4 order-1 xl:order-1">
             <div className="glass-panel p-6 md:p-8 rounded-3xl shadow-xl shadow-blue-100/50 sticky top-28 border border-white/60">
               <h3 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-3">
                 <div className="p-2 bg-blue-100 rounded-lg text-blue-600"><PlusCircle className="w-6 h-6" /></div>
                 Assign Vehicle
               </h3>
               <form onSubmit={handleAddBus} className="space-y-5">
                 <div>
                   <label className="block text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Bus Identifier</label>
                   <input 
                    type="text" 
                    placeholder="e.g. BUS-404"
                    className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-blue-400 outline-none transition-all font-semibold text-slate-700 placeholder:text-slate-400"
                    value={newBusNum}
                    onChange={e => setNewBusNum(e.target.value)}
                    required
                   />
                 </div>
                 <div>
                   <label className="block text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Assigned Driver</label>
                   <div className="relative">
                     <select 
                       className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-blue-400 outline-none transition-all font-semibold text-slate-700 appearance-none cursor-pointer"
                       value={newBusDriver}
                       onChange={e => setNewBusDriver(e.target.value)}
                       required
                     >
                       <option value="">Select Driver Account...</option>
                       {users.filter(u => u.role === 'DRIVER').map(u => (
                         <option key={u.id} value={u.name}>{u.name}</option>
                       ))}
                     </select>
                     <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                        <ArrowRight className="w-4 h-4 rotate-90" />
                     </div>
                   </div>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Start Point</label>
                        <input type="text" value={newBusStart} onChange={e => setNewBusStart(e.target.value)} className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-400 outline-none font-semibold text-slate-700" />
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">End Point</label>
                        <input type="text" value={newBusEnd} onChange={e => setNewBusEnd(e.target.value)} className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-400 outline-none font-semibold text-slate-700" />
                    </div>
                 </div>
                 <button type="submit" className="w-full py-4 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl transition-all shadow-lg hover:shadow-slate-500/20 text-lg mt-2">
                   Deploy Bus
                 </button>
               </form>
             </div>
          </div>

          {/* Bus List */}
          <div className="xl:col-span-8 space-y-5 order-2 xl:order-2">
            {buses.length === 0 ? (
                <div className="p-12 text-center text-slate-400 glass-panel rounded-3xl border border-dashed border-slate-300">
                    <p className="text-xl font-medium">Fleet is currently empty.</p>
                </div>
            ) : (
                buses.map(bus => (
                    <div key={bus.id} className="glass-panel p-6 rounded-2xl shadow-sm border border-white/60 hover:shadow-md transition-all group">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                            <div className="flex-1">
                                <div className="flex items-center gap-4 mb-3">
                                    <span className="text-3xl font-extrabold text-slate-800 tracking-tight">{bus.busNumber}</span>
                                    <span className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider border backdrop-blur-md shadow-sm ${getStatusColor(bus.status)}`}>
                                        {bus.status}
                                    </span>
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-8 text-slate-600">
                                    <p className="flex items-center gap-2"><span className="font-bold text-slate-400 uppercase text-xs w-16">Driver</span> <span className="text-lg font-semibold">{bus.driverName}</span></p>
                                    <p className="flex items-center gap-2"><span className="font-bold text-slate-400 uppercase text-xs w-16">Loc</span> <span className="text-lg font-semibold text-indigo-700">{bus.currentStop}</span></p>
                                    <p className="flex items-center gap-2"><span className="font-bold text-slate-400 uppercase text-xs w-16">Route</span> <span className="font-medium">{bus.routeStart} &rarr; {bus.routeEnd}</span></p>
                                    <p className="flex items-center gap-2"><span className="font-bold text-slate-400 uppercase text-xs w-16">Stops</span> <span className="font-medium">{bus.stops.length} registered</span></p>
                                </div>
                            </div>
                            <button 
                                onClick={() => deleteBus(bus.id)}
                                className="self-end md:self-center p-3 rounded-xl text-rose-500 hover:bg-rose-50 hover:text-rose-700 transition-colors border border-transparent hover:border-rose-100"
                                title="Remove Bus"
                            >
                                <Trash2 className="w-6 h-6" />
                            </button>
                        </div>
                    </div>
                ))
            )}
          </div>
        </div>
      )}

      {activeTab === 'USERS' && (
        <div className="grid xl:grid-cols-12 gap-8">
            {/* Add User Form */}
            <div className="xl:col-span-4 order-1">
                <div className="glass-panel p-6 md:p-8 rounded-3xl shadow-xl shadow-indigo-100/50 sticky top-28 border border-white/60">
                    <h3 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-3">
                        <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600"><PlusCircle className="w-6 h-6" /></div>
                        Register User
                    </h3>
                    <form onSubmit={handleAddUser} className="space-y-5">
                        <div>
                        <label className="block text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Full Name</label>
                        <input 
                            type="text" 
                            className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none transition-all font-semibold text-slate-700 placeholder:text-slate-400"
                            value={newUserName}
                            onChange={e => setNewUserName(e.target.value)}
                            required
                        />
                        </div>
                        <div>
                        <label className="block text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">System Role</label>
                        <div className="relative">
                            <select 
                                className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none transition-all font-semibold text-slate-700 appearance-none cursor-pointer"
                                value={newUserRole}
                                onChange={e => setNewUserRole(e.target.value as any)}
                            >
                                <option value="DRIVER">Bus Driver</option>
                                <option value="STUDENT">Student</option>
                            </select>
                            <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                                <ArrowRight className="w-4 h-4 rotate-90" />
                            </div>
                        </div>
                        </div>
                        <button type="submit" className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-indigo-200 hover:shadow-indigo-300 text-lg mt-2">
                            Create Account
                        </button>
                    </form>
                </div>
            </div>

            {/* User List */}
            <div className="xl:col-span-8 order-2">
                <div className="glass-panel rounded-3xl overflow-hidden shadow-sm border border-white/60">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left min-w-[600px]">
                            <thead className="bg-slate-50/80 border-b border-slate-200 backdrop-blur-sm">
                                <tr>
                                    <th className="p-6 font-bold text-slate-400 uppercase text-xs tracking-wider">User Identity</th>
                                    <th className="p-6 font-bold text-slate-400 uppercase text-xs tracking-wider">Role Access</th>
                                    <th className="p-6 font-bold text-slate-400 uppercase text-xs tracking-wider">Registration Time</th>
                                    <th className="p-6 font-bold text-slate-400 uppercase text-xs tracking-wider text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {users.map(user => (
                                    <tr key={user.id} className="hover:bg-blue-50/30 transition-colors group">
                                        <td className="p-6">
                                            <span className="text-lg font-bold text-slate-700">{user.name}</span>
                                        </td>
                                        <td className="p-6">
                                            <span className={`inline-block px-3 py-1 rounded-lg text-xs font-extrabold uppercase tracking-wide border shadow-sm ${
                                                user.role === 'ADMIN' ? 'bg-violet-100 text-violet-700 border-violet-200' :
                                                user.role === 'DRIVER' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                                                'bg-blue-100 text-blue-700 border-blue-200'
                                            }`}>
                                                {user.role}
                                            </span>
                                        </td>
                                        <td className="p-6">
                                            <div className="flex items-center gap-2 text-slate-500 font-medium font-mono">
                                                <Clock className="w-4 h-4 text-slate-400" />
                                                {new Date(user.joinedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                                            </div>
                                        </td>
                                        <td className="p-6 text-right">
                                            {user.role !== 'ADMIN' && (
                                                <button 
                                                    onClick={() => deleteUser(user.id)}
                                                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                                >
                                                    <Trash2 className="w-5 h-5" />
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="max-w-2xl mx-auto">
             <div className="glass-panel p-6 md:p-10 rounded-3xl shadow-2xl shadow-amber-500/10 border border-white/60">
                 <div className="text-center mb-8">
                     <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-600 shadow-inner">
                         <Lock className="w-10 h-10" />
                     </div>
                     <h3 className="text-3xl font-black text-slate-800 mb-2">Security Settings</h3>
                     <p className="text-slate-500 font-medium">Update administrator access credentials.</p>
                 </div>

                 {settingsMsg && (
                    <div className="mb-6 bg-emerald-100 border border-emerald-200 text-emerald-700 p-4 rounded-xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                        <CheckCircle className="w-5 h-5" />
                        <span className="font-bold">{settingsMsg}</span>
                    </div>
                 )}

                 <form onSubmit={handleUpdateSettings} className="space-y-6">
                     <div>
                        <label className="block text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Admin Username</label>
                        <input 
                            type="text" 
                            className="w-full px-5 py-4 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-amber-400 outline-none transition-all font-semibold text-slate-700 text-lg"
                            value={adminName}
                            onChange={e => setAdminName(e.target.value)}
                            required
                        />
                     </div>
                     <div>
                        <label className="block text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Access Password</label>
                        <input 
                            type="text" 
                            className="w-full px-5 py-4 bg-white/50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-amber-400 outline-none transition-all font-semibold text-slate-700 text-lg font-mono"
                            value={adminPass}
                            onChange={e => setAdminPass(e.target.value)}
                            required
                        />
                        <p className="text-xs text-amber-600 mt-2 font-medium flex items-center gap-1">
                            <Lock className="w-3 h-3" /> Password is visible for editing confirmation.
                        </p>
                     </div>
                     
                     <div className="pt-4">
                        <button type="submit" className="w-full py-4 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-amber-200 hover:shadow-amber-300 text-lg flex items-center justify-center gap-2">
                            <Settings className="w-5 h-5" />
                            Save Changes
                        </button>
                        <p className="text-center text-xs text-slate-400 mt-4">Make sure to remember these new credentials for your next login.</p>
                     </div>
                 </form>
             </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;