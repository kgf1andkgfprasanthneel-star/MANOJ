import React, { useState } from 'react';
import { Role } from '../types';
import { useSystem } from '../context/SystemContext';
import { UserPlus, ArrowRight, Sparkles, LogIn, Lock, AlertCircle } from 'lucide-react';

interface RoleSelectionProps {
  onSelectRole: (role: Role) => void;
}

const RoleSelection: React.FC<RoleSelectionProps> = ({ onSelectRole }) => {
  const { addUser, login, users, adminCredentials } = useSystem();
  
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [regName, setRegName] = useState('');
  const [regRole, setRegRole] = useState<'DRIVER' | 'STUDENT'>('STUDENT');
  const [loginName, setLoginName] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPasswordInput, setShowPasswordInput] = useState(false);
  const [loginError, setLoginError] = useState('');

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const nameTrim = regName.trim();
    if (!nameTrim) return;

    if (nameTrim.toLowerCase() === adminCredentials.name.toLowerCase()) {
      setLoginError('Cannot register as Admin. Use existing Admin credentials.');
      return;
    }
    
    // Prevent creating a new record if name already exists
    const existing = users.find(u => u.name.toLowerCase() === nameTrim.toLowerCase());
    if (existing) {
      setLoginError('This identity already exists. Please log in instead.');
      setIsLoginMode(true);
      setLoginName(nameTrim);
      return;
    }

    addUser({ name: nameTrim, role: regRole });
    
    setTimeout(() => {
        const user = login(nameTrim);
        if (user) onSelectRole(user.role);
    }, 150);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const nameTrim = loginName.trim();
    const isAdminAttempt = nameTrim.toLowerCase() === adminCredentials.name.toLowerCase();

    if (isAdminAttempt) {
      if (!showPasswordInput) {
        setShowPasswordInput(true);
        return;
      }
      if (loginPassword === adminCredentials.password) {
        const adminUser = login(adminCredentials.name);
        if (adminUser) onSelectRole('ADMIN');
      } else {
        setLoginError('Invalid Administrator Password');
      }
      return;
    }

    if (nameTrim) {
      const user = login(nameTrim);
      if (user) onSelectRole(user.role);
      else setLoginError('Identity not found. Please register first.');
    }
  };

  const handleAdminCardClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsLoginMode(true);
    setLoginName(adminCredentials.name);
    setShowPasswordInput(true);
    
    // Simple focus shift is often better than complex scrolling on Android
    setTimeout(() => {
        const input = document.querySelector('input[type="password"]') as HTMLElement;
        if (input) input.focus();
    }, 100);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[75vh] py-8">
      <div className="text-center mb-10 md:mb-16 max-w-4xl px-4 animate-in fade-in zoom-in duration-1000">
        <h2 className="text-5xl sm:text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-200 to-slate-600 mb-4 md:mb-6 pb-2 drop-shadow-[0_0_25px_rgba(255,255,255,0.2)] tracking-tighter">
          CAMPUS<br/>TRANSIT
        </h2>
        <div className="h-1 w-24 md:w-32 bg-gradient-to-r from-cyan-500 to-fuchsia-500 mx-auto rounded-full mb-8 shadow-[0_0_20px_rgba(6,182,212,0.8)]"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-6xl px-4 mb-12 md:mb-20">
        <button 
          type="button"
          onClick={handleAdminCardClick} 
          className="group relative glass-panel p-6 rounded-[24px] transition-all duration-300 hover:-translate-y-1 hover:bg-white/5 text-left flex items-center gap-4 border border-white/5 hover:border-blue-500/30 w-full cursor-pointer touch-manipulation"
        >
          <div className="w-12 h-12 bg-slate-800 rounded-xl flex items-center justify-center shadow-inner group-hover:bg-blue-900/50 transition-colors pointer-events-none">
            <Lock className="w-6 h-6 text-blue-400" />
          </div>
          <div className="pointer-events-none">
            <h3 className="text-lg font-bold text-white group-hover:text-blue-300 transition-colors">Admin Portal</h3>
            <p className="text-slate-500 text-xs uppercase tracking-wider">Restricted Access</p>
          </div>
        </button>
      </div>

      <div id="login-form-container" className="w-full max-w-md relative min-h-[500px] px-4 md:px-0">
         <div className="custom-form transition-all duration-500">
            <div className="flex w-full mb-6 bg-black/40 rounded-xl p-1 border border-white/5">
                <button type="button" onClick={() => { setIsLoginMode(true); setLoginError(''); }} className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all cursor-pointer touch-manipulation ${isLoginMode ? 'bg-[#ff2770] text-white shadow-[0_0_15px_rgba(255,39,112,0.4)]' : 'text-slate-500 hover:text-white'}`}>Login</button>
                <button type="button" onClick={() => { setIsLoginMode(false); setLoginError(''); }} className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all cursor-pointer touch-manipulation ${!isLoginMode ? 'bg-[#45f3ff] text-slate-900 shadow-[0_0_15px_rgba(69,243,255,0.4)]' : 'text-slate-500 hover:text-white'}`}>Register</button>
            </div>

            <div className="loginBx relative">
                {isLoginMode ? (
                    <form onSubmit={handleLogin} className="w-full flex flex-col gap-6 animate-in slide-in-from-left-4 duration-300">
                        <div className="flex items-center gap-3 mb-2 justify-center">
                            {showPasswordInput ? <Lock className="w-6 h-6 text-amber-500 animate-pulse" /> : <LogIn className="w-6 h-6 text-[#ff2770]" />}
                            <h3 className="text-2xl font-bold text-white tracking-wide">{showPasswordInput ? 'VERIFY IDENTITY' : 'WELCOME BACK'}</h3>
                        </div>
                        <div className="flex flex-col gap-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1">Registered Name</label>
                            <input type="text" value={loginName} onChange={(e) => setLoginName(e.target.value)} className="w-full p-4 bg-black/30 border border-white/10 rounded-xl text-white outline-none focus:border-[#ff2770] focus:shadow-[0_0_15px_rgba(255,39,112,0.3)] transition-all font-medium placeholder:text-slate-600" placeholder="Enter your name..." required />
                        </div>
                        {showPasswordInput && (
                            <div className="flex flex-col gap-2 animate-in fade-in slide-in-from-bottom-2 duration-300">
                                <label className="text-xs font-bold text-amber-500 uppercase tracking-widest pl-1 flex items-center gap-2"><Lock className="w-3 h-3" /> Password Required</label>
                                <input type="password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} className="w-full p-4 bg-black/30 border border-amber-500/50 rounded-xl text-white outline-none focus:border-amber-500 focus:shadow-[0_0_15px_rgba(245,158,11,0.3)] transition-all font-medium placeholder:text-slate-600" placeholder="Enter Admin Password..." autoFocus required />
                            </div>
                        )}
                        {loginError && (
                            <div className="flex items-center gap-2 text-red-400 bg-red-400/10 p-3 rounded-lg border border-red-400/20">
                                <AlertCircle className="w-4 h-4 flex-shrink-0" /><p className="text-[10px] font-bold">{loginError}</p>
                            </div>
                        )}
                        <button type="submit" className={`mt-4 p-4 rounded-xl font-bold text-white transition-all text-sm uppercase tracking-widest hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 touch-manipulation cursor-pointer ${showPasswordInput ? 'bg-amber-600 hover:bg-amber-500 shadow-[0_0_20px_rgba(217,119,6,0.4)]' : 'bg-[#ff2770] hover:bg-[#ff0f60] shadow-[0_0_20px_rgba(255,39,112,0.4)]'}`}>
                            <span>{showPasswordInput ? 'Verify & Enter' : 'Access Dashboard'}</span><ArrowRight className="w-4 h-4" />
                        </button>
                    </form>
                ) : (
                    <form onSubmit={handleRegister} className="w-full flex flex-col gap-5 animate-in slide-in-from-right-4 duration-300">
                        <div className="flex items-center gap-3 mb-2 justify-center"><UserPlus className="w-6 h-6 text-[#45f3ff]" /><h3 className="text-2xl font-bold text-white tracking-wide">NEW PROFILE</h3></div>
                        <div className="flex flex-col gap-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1">Identity Name</label>
                            <input type="text" value={regName} onChange={(e) => setRegName(e.target.value)} className="w-full p-3 bg-black/30 border border-white/10 rounded-xl text-white outline-none focus:border-[#45f3ff] focus:shadow-[0_0_15px_rgba(69,243,255,0.3)] transition-all font-medium" placeholder="Enter Full Name..." required />
                        </div>
                        <div className="flex flex-col gap-2">
                            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1">Access Role</label>
                            <div className="relative">
                                <select value={regRole} onChange={(e) => setRegRole(e.target.value as any)} className="w-full p-3 bg-black/30 border border-white/10 rounded-xl text-white outline-none appearance-none focus:border-[#45f3ff] focus:shadow-[0_0_15px_rgba(69,243,255,0.3)] transition-all font-medium cursor-pointer">
                                    <option value="STUDENT">Student</option>
                                    <option value="DRIVER">Driver</option>
                                </select><ArrowRight className="absolute right-3 top-3.5 w-4 h-4 text-slate-500 rotate-90 pointer-events-none" />
                            </div>
                        </div>
                        {loginError && (
                            <div className="flex items-center gap-2 text-red-400 bg-red-400/10 p-3 rounded-lg border border-red-400/20">
                                <AlertCircle className="w-4 h-4 flex-shrink-0" /><p className="text-[10px] font-bold">{loginError}</p>
                            </div>
                        )}
                        <button type="submit" className="mt-4 p-3 rounded-xl font-bold text-slate-900 bg-[#45f3ff] hover:bg-[#33d4e0] shadow-[0_0_20px_rgba(69,243,255,0.4)] transition-all text-sm uppercase tracking-widest hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 touch-manipulation cursor-pointer">
                            <Sparkles className="w-4 h-4" /> Create & Enter
                        </button>
                    </form>
                )}
            </div>
         </div>
      </div>
    </div>
  );
};

export default RoleSelection;