import React, { useState, useEffect } from 'react';
import { useSystem } from '../context/SystemContext';
import { BusStatus } from '../types';
import { MapPin, Clock, AlertCircle, PlayCircle, StopCircle, Plus, Zap, ArrowRight, Bus as BusIcon } from 'lucide-react';

const DriverDashboard: React.FC = () => {
  const { buses, updateBusStatus, addStopToBus, currentUser } = useSystem();
  const [selectedBusId, setSelectedBusId] = useState<string>('');
  const [newStopName, setNewStopName] = useState('');

  // FILTER: Only show buses where driverName matches current user
  const myBuses = buses.filter(b => b.driverName.toLowerCase() === currentUser?.name.toLowerCase());

  // Auto-select the first assigned bus on load
  useEffect(() => {
    if (myBuses.length > 0 && !selectedBusId) {
        setSelectedBusId(myBuses[0].id);
    }
  }, [myBuses, selectedBusId]);

  const selectedBus = buses.find(b => b.id === selectedBusId);

  const handleStatusChange = (status: BusStatus) => {
    if (!selectedBusId) return;
    updateBusStatus(selectedBusId, { status });
  };

  const handleLocationUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const location = formData.get('currentLocation') as string;
    
    if (selectedBus && location) {
        updateBusStatus(selectedBus.id, {
            lastPassedStop: selectedBus.currentStop,
            currentStop: location
        });
        (e.target as HTMLFormElement).reset();
    }
  };

  const handleAddStop = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedBusId && newStopName) {
        addStopToBus(selectedBusId, newStopName);
        setNewStopName('');
    }
  };

  // If no bus assigned
  if (myBuses.length === 0) {
    return (
        <div className="flex flex-col items-center justify-center min-h-[50vh] animate-in fade-in zoom-in duration-500 px-4">
            <div className="w-24 h-24 bg-slate-800 rounded-full flex items-center justify-center mb-6 shadow-2xl border border-white/10">
                <BusIcon className="w-10 h-10 text-slate-500" />
            </div>
            <h2 className="text-3xl font-black text-slate-700 mb-2 text-center">No Vehicle Assigned</h2>
            <p className="text-slate-500 font-medium max-w-md text-center">
                Hello <span className="text-emerald-500 font-bold">{currentUser?.name}</span>. The administrator has not assigned you to a route yet. Please contact dispatch.
            </p>
        </div>
    );
  }

  if (!selectedBus) return null;

  return (
    <div className="max-w-5xl mx-auto space-y-6 md:space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      
      {/* Header Info Bar */}
      <div className="glass-panel p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg shadow-indigo-100/50 border border-white/80">
        <div>
            <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-600">
                     <BusIcon className="w-6 h-6" />
                </div>
                <div>
                    <h2 className="text-3xl font-black text-slate-800 tracking-tight">{selectedBus.busNumber}</h2>
                    <span className="text-[10px] font-bold uppercase text-slate-500 tracking-widest">Operator: {currentUser?.name}</span>
                </div>
            </div>
        </div>
        
        <div className="bg-emerald-500/10 px-4 py-2 rounded-lg border border-emerald-500/20 w-fit">
             <p className="text-emerald-700 font-bold text-xs uppercase tracking-widest flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                Active Transmission
             </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6 md:gap-8">
        {/* Status Control Panel */}
        <div className="glass-panel p-6 md:p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-white/60 space-y-8 h-fit">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
                <div className="p-2 bg-indigo-50 rounded-lg"><Zap className="w-5 h-5 text-indigo-600" /></div>
                <h3 className="text-xl font-bold text-slate-800">Live Status Controls</h3>
            </div>
            
            {/* Mobile: Stack vertically for easy thumb access. Desktop: Grid of 3 */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button
                    onClick={() => handleStatusChange('Running')}
                    className={`flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all duration-300 shadow-sm ${selectedBus.status === 'Running' ? 'border-emerald-500 bg-emerald-50 text-emerald-700 shadow-emerald-200' : 'border-slate-100 bg-white hover:border-emerald-200 hover:shadow-md'}`}
                >
                    <PlayCircle className={`w-8 h-8 md:w-10 md:h-10 mb-2 ${selectedBus.status === 'Running' ? 'animate-pulse' : ''}`} />
                    <span className="font-bold text-sm tracking-wide">RUNNING</span>
                </button>
                <button
                    onClick={() => handleStatusChange('Delayed')}
                    className={`flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all duration-300 shadow-sm ${selectedBus.status === 'Delayed' ? 'border-amber-500 bg-amber-50 text-amber-700 shadow-amber-200' : 'border-slate-100 bg-white hover:border-amber-200 hover:shadow-md'}`}
                >
                    <Clock className="w-8 h-8 md:w-10 md:h-10 mb-2" />
                    <span className="font-bold text-sm tracking-wide">DELAYED</span>
                </button>
                <button
                    onClick={() => handleStatusChange('Reached')}
                    className={`flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all duration-300 shadow-sm ${selectedBus.status === 'Reached' ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-blue-200' : 'border-slate-100 bg-white hover:border-blue-200 hover:shadow-md'}`}
                >
                    <StopCircle className="w-8 h-8 md:w-10 md:h-10 mb-2" />
                    <span className="font-bold text-sm tracking-wide">ARRIVED</span>
                </button>
            </div>

            <div className="bg-slate-50/80 p-6 rounded-2xl border border-slate-200">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Location Update Override</h4>
                
                {/* Route Configuration Options */}
                {selectedBus.stops && selectedBus.stops.length > 0 && (
                    <div className="mb-4">
                        <label className="text-xs font-bold text-slate-500 mb-2 block">Quick Select from Route</label>
                        <div className="relative">
                            <select 
                                className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none font-bold text-slate-700 appearance-none cursor-pointer transition-all hover:border-indigo-300 shadow-sm"
                                onChange={(e) => {
                                    if (e.target.value) {
                                        updateBusStatus(selectedBus.id, {
                                            lastPassedStop: selectedBus.currentStop,
                                            currentStop: e.target.value
                                        });
                                        e.target.value = ""; // Reset to placeholder
                                    }
                                }}
                                defaultValue=""
                            >
                                <option value="" disabled>Select Next Stop...</option>
                                {selectedBus.stops.map((stop) => (
                                    <option key={stop.id} value={stop.name}>
                                    {stop.order}. {stop.name}
                                    </option>
                                ))}
                            </select>
                            <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                                <ArrowRight className="w-4 h-4 rotate-90" />
                            </div>
                        </div>
                        <div className="flex items-center gap-2 my-3">
                            <div className="h-px bg-slate-200 flex-1"></div>
                            <span className="text-[10px] font-bold text-slate-400 uppercase">OR MANUAL ENTRY</span>
                            <div className="h-px bg-slate-200 flex-1"></div>
                        </div>
                    </div>
                )}

                <form onSubmit={handleLocationUpdate} className="flex gap-3">
                    <input 
                        name="currentLocation"
                        type="text" 
                        placeholder="Type location..."
                        className="flex-1 px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none font-semibold text-slate-700 placeholder:text-slate-400 w-full"
                        required
                    />
                    <button type="submit" className="bg-slate-800 hover:bg-slate-900 text-white px-6 rounded-xl font-bold transition-shadow hover:shadow-lg">
                        Set
                    </button>
                </form>
            </div>
        </div>

        {/* Current State Info */}
        <div className="space-y-6 md:space-y-8">
            <div className="glass-panel p-6 md:p-8 rounded-3xl shadow-xl shadow-blue-50/50 border border-white/60">
                <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                    <div className="w-2 h-6 bg-blue-500 rounded-full"></div>
                    Live Telemetry
                </h3>
                <div className="space-y-6">
                    <div className="flex items-start gap-5 group">
                        <div className="p-3 bg-blue-50 rounded-2xl text-blue-600 group-hover:scale-110 transition-transform"><MapPin className="w-8 h-8" /></div>
                        <div>
                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">Current Position</p>
                            <p className="text-2xl md:text-3xl font-black text-slate-800 leading-none break-words">{selectedBus.currentStop}</p>
                        </div>
                    </div>
                    <div className="w-full h-px bg-slate-100"></div>
                    <div className="flex items-start gap-5 group">
                        <div className="p-3 bg-indigo-50 rounded-2xl text-indigo-400 group-hover:scale-110 transition-transform"><Clock className="w-8 h-8" /></div>
                        <div>
                            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">Last Passed</p>
                            <p className="text-xl md:text-2xl font-bold text-slate-600 break-words">{selectedBus.lastPassedStop}</p>
                        </div>
                    </div>
                    <div className="w-full h-px bg-slate-100"></div>
                    <div className="flex items-center gap-4 pt-2">
                        <AlertCircle className="w-5 h-5 text-emerald-500" />
                        <div className="flex flex-wrap items-center gap-2">
                           <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Last Sync:</p>
                           <p className="text-lg font-mono font-bold text-emerald-600 bg-emerald-50 px-2 rounded-md">
                               {new Date(selectedBus.lastUpdated).toLocaleTimeString()}
                           </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Manual Route Management */}
            <div className="glass-panel p-6 md:p-8 rounded-3xl border border-white/60">
                 <h3 className="text-lg font-bold text-slate-800 mb-4">Route Configuration</h3>
                 
                 <div className="mb-6 max-h-40 overflow-y-auto pr-2 custom-scrollbar">
                    {selectedBus.stops.length === 0 ? (
                        <p className="text-slate-400 text-sm italic font-medium">No stops configured for this route.</p>
                    ) : (
                        <ul className="space-y-3">
                            {selectedBus.stops.map((stop, idx) => (
                                <li key={stop.id} className="text-base font-semibold flex items-center gap-4 text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100">
                                    <span className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-sm font-black text-slate-400 shadow-sm border border-slate-100 flex-shrink-0">{idx + 1}</span>
                                    <span className="truncate">{stop.name}</span>
                                </li>
                            ))}
                        </ul>
                    )}
                 </div>

                 <form onSubmit={handleAddStop} className="flex gap-3">
                    <input 
                        type="text"
                        value={newStopName}
                        onChange={(e) => setNewStopName(e.target.value)}
                        placeholder="Add stop manually..."
                        className="flex-1 px-4 py-3 bg-white/50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-slate-300 w-full"
                        required
                    />
                    <button type="submit" className="bg-slate-200 text-slate-700 p-3 rounded-xl hover:bg-slate-300 transition-colors">
                        <Plus className="w-6 h-6" />
                    </button>
                 </form>
            </div>
        </div>
      </div>
    </div>
  );
};

export default DriverDashboard;