
export type Role = 'ADMIN' | 'DRIVER' | 'STUDENT' | null;

export type BusStatus = 'Running' | 'Delayed' | 'Reached' | 'Maintenance';

export interface Stop {
  id: string;
  name: string;
  order: number;
}

export interface Bus {
  id: string;
  busNumber: string;
  driverName: string;
  routeStart: string;
  routeEnd: string;
  currentStop: string;
  lastPassedStop: string;
  status: BusStatus;
  lastUpdated: string; // ISO string
  stops: Stop[];
}

export interface User {
  id: string;
  name: string;
  role: 'ADMIN' | 'DRIVER' | 'STUDENT';
  joinedAt: string; // ISO string for creation time
}

export const ADMIN_CREDENTIALS = {
  name: 'admin',
  password: 'admin'
};

export const INITIAL_BUSES: Bus[] = [
  {
    id: '1',
    busNumber: 'BUS-101',
    driverName: 'John Doe',
    routeStart: 'Campus Main',
    routeEnd: 'Downtown Station',
    currentStop: 'Library Corner',
    lastPassedStop: 'Engineering Dept',
    status: 'Running',
    lastUpdated: new Date().toISOString(),
    stops: [
      { id: 's1', name: 'Campus Main', order: 1 },
      { id: 's2', name: 'Engineering Dept', order: 2 },
      { id: 's3', name: 'Library Corner', order: 3 },
      { id: 's4', name: 'Downtown Station', order: 4 },
    ]
  },
  {
    id: '2',
    busNumber: 'BUS-202',
    driverName: 'Sarah Smith',
    routeStart: 'North Dorms',
    routeEnd: 'Science Park',
    currentStop: 'Waiting at Terminal',
    lastPassedStop: 'N/A',
    status: 'Delayed',
    lastUpdated: new Date(Date.now() - 1000 * 60 * 15).toISOString(), // 15 mins ago
    stops: [
      { id: 's5', name: 'North Dorms', order: 1 },
      { id: 's6', name: 'Cafeteria', order: 2 },
      { id: 's7', name: 'Science Park', order: 3 },
    ]
  }
];

export const INITIAL_USERS: User[] = [
  { id: 'u1', name: 'admin', role: 'ADMIN', joinedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString() },
  { id: 'u2', name: 'John Doe', role: 'DRIVER', joinedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString() },
  { id: 'u3', name: 'Sarah Smith', role: 'DRIVER', joinedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString() },
  { id: 'u4', name: 'Alice Student', role: 'STUDENT', joinedAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString() },
];
