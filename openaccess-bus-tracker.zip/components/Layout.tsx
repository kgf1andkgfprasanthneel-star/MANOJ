import React, { useState } from 'react';
import { Role } from '../types';
import { LogOut, AlertTriangle } from 'lucide-react';
import { useSystem } from '../context/SystemContext';

interface LayoutProps {
  children: React.ReactNode;
  currentRole: Role;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, currentRole, onLogout }) => {
  const { logout } = useSystem();

  const handleLogout = () => {
    logout();
    onLogout();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#050505] via-[#0a0a12] to-[#050505] text-white font-sans selection:bg-fuchsia-500/30 selection:text-fuchsia-200 overflow-x-hidden">
      
      {/* Disclaimer Banner - Dark Glow */}
      <div className="bg-amber-900/20 border-b border-amber-500/20 backdrop-blur-md px-4 py-2 text-xs font-medium text-amber-500 flex items-center justify-center gap-3 shadow-[0_0_20px_rgba(245,158,11,0.1)] relative z-50 text-center">
        <AlertTriangle className="w-4 h-4 flex-shrink-0" />
        <span className="tracking-[0.2em] uppercase">Academic Demo • Unsecured</span>
      </div>

      {/* Glassmorphic Header */}
      <header className="sticky top-0 z-40 px-4 py-4 md:py-6 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto glass-panel rounded-2xl md:rounded-full shadow-2xl shadow-black/50 px-4 md:px-8 py-3 md:h-20 flex flex-wrap md:flex-nowrap items-center justify-between transition-all duration-300 border border-white/5 gap-4">
          <div className="flex items-center gap-3 md:gap-4">
            <div className="w-8 h-8 md:w-10 md:h-10 bg-gradient-to-tr from-cyan-500 to-blue-600 rounded-full flex items-center justify-center text-white font-black text-sm md:text-lg shadow-[0_0_20px_rgba(6,182,212,0.5)] flex-shrink-0">
              BT
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-slate-400 drop-shadow-[0_0_10px_rgba(255,255,255,0.3)]">
                BusTracker
              </h1>
            </div>
          </div>
          
          <div className="flex items-center gap-3 md:gap-6 ml-auto">
            {currentRole && (
              <>
                <div className="hidden md:flex flex-col items-end">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Access Level</span>
                  <span className="text-lg font-bold text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]">{currentRole}</span>
                </div>
                
                {/* Mobile Compact Badge */}
                <div className="md:hidden px-3 py-1 bg-cyan-900/30 rounded-full border border-cyan-500/30 backdrop-blur-sm">
                   <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">{currentRole}</span>
                </div>

                <button 
                  onClick={handleLogout}
                  className="flex items-center gap-2 bg-white/5 hover:bg-red-500/20 text-red-400 hover:text-red-300 border border-white/10 hover:border-red-500/50 px-4 md:px-6 py-2 md:py-2.5 rounded-full text-[10px] md:text-xs font-black uppercase tracking-widest transition-all shadow-lg hover:shadow-red-900/40 group whitespace-nowrap"
                >
                  <LogOut className="w-3 h-3 md:w-4 md:h-4 group-hover:scale-110 transition-transform" />
                  Exit
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-10 relative z-0">
        {children}
      </main>

      {/* Footer */}
      <footer className="py-8 mt-auto border-t border-white/5 bg-black/20 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="font-bold text-slate-500 tracking-[0.2em] text-xs">HIGH-FIDELITY DEMO SYSTEM</p>
          <p className="mt-2 text-slate-600 text-[10px] uppercase">Node.js + React • Mobile Optimized • No API Keys</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;