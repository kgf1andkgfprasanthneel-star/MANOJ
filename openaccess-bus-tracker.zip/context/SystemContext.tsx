import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Bus, User, INITIAL_BUSES, INITIAL_USERS, Stop, ADMIN_CREDENTIALS } from '../types';

interface SystemContextType {
  buses: Bus[];
  users: User[];
  currentUser: User | null;
  adminCredentials: { name: string; password: string };
  addBus: (bus: Omit<Bus, 'id' | 'lastUpdated'>) => void;
  updateBusStatus: (busId: string, updates: Partial<Bus>) => void;
  addStopToBus: (busId: string, stopName: string) => void;
  addUser: (user: Omit<User, 'id' | 'joinedAt'>) => void;
  deleteUser: (userId: string) => void;
  deleteBus: (busId: string) => void;
  login: (name: string) => User | null;
  logout: () => void;
  updateAdminCredentials: (name: string, pass: string) => void;
}

const SystemContext = createContext<SystemContextType | undefined>(undefined);

// Helper for Session Storage (Local device only)
const getSessionUser = (): User | null => {
  if (typeof window === 'undefined') return null;
  try {
    const item = localStorage.getItem('currentUser');
    return item ? JSON.parse(item) : null;
  } catch { return null; }
};

export const SystemProvider = ({ children }: { children?: ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(getSessionUser);

  // Default to initial data, but these will be overwritten by server data
  const [buses, setBuses] = useState<Bus[]>(INITIAL_BUSES);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [adminCredentials, setAdminCredentials] = useState(ADMIN_CREDENTIALS);

  // --- UNIFIED API STRATEGY ---
  // By using a relative path, the browser will automatically direct the request
  // to the same origin serving the app (e.g., https://my-app.ngrok.io/api/data).
  // This solves CORS and connectivity issues across different networks.
  const API_URL = '/api';

  // --- SYNC ENGINE ---
  
  const fetchData = async () => {
    try {
      // Add timestamp (?t=...) to prevent aggressive browser/network caching
      const res = await fetch(`${API_URL}/data?t=${Date.now()}`, {
        method: 'GET',
        headers: { 
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache' 
        }
      });

      const contentType = res.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        const data = await res.json();
        if (Array.isArray(data.buses)) setBuses(data.buses);
        if (Array.isArray(data.users)) setUsers(data.users);
        if (data.adminCredentials) setAdminCredentials(data.adminCredentials);
      }
    } catch (error) {
      // Silent fail on network error, will retry in 2s
    }
  };

  const pushUpdate = async (payload: { buses?: Bus[], users?: User[], adminCredentials?: any }) => {
    try {
      await fetch(`${API_URL}/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      // Immediately fetch back to ensure consistency
      fetchData();
    } catch (error) {
      console.error("Failed to push update:", error);
      alert("Network Error: Could not reach the server. Changes saved locally only.");
    }
  };

  // --- LIFECYCLE ---

  useEffect(() => {
    fetchData(); // Initial load
    const interval = setInterval(fetchData, 2000); // Polling every 2s
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('currentUser');
    }
  }, [currentUser]);

  // --- ACTIONS ---

  const addBus = (busData: Omit<Bus, 'id' | 'lastUpdated'>) => {
    if (currentUser?.role !== 'ADMIN') {
        alert("Permission Denied");
        return;
    }
    const newBus: Bus = {
      ...busData,
      id: `bus-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      lastUpdated: new Date().toISOString(),
    };
    
    const newBuses = [...buses, newBus];
    setBuses(newBuses); 
    pushUpdate({ buses: newBuses });
  };

  const updateBusStatus = (busId: string, updates: Partial<Bus>) => {
    const newBuses = buses.map(bus => 
      bus.id === busId ? { ...bus, ...updates, lastUpdated: new Date().toISOString() } : bus
    );
    setBuses(newBuses);
    pushUpdate({ buses: newBuses });
  };

  const addStopToBus = (busId: string, stopName: string) => {
    const newBuses = buses.map(bus => {
      if (bus.id === busId) {
        const newStop: Stop = { 
            id: `stop-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`, 
            name: stopName, 
            order: bus.stops.length + 1 
        };
        return { ...bus, stops: [...bus.stops, newStop] };
      }
      return bus;
    });
    setBuses(newBuses);
    pushUpdate({ buses: newBuses });
  };

  const deleteBus = (busId: string) => {
    if (currentUser?.role !== 'ADMIN') return;
    const newBuses = buses.filter(b => b.id !== busId);
    setBuses(newBuses);
    pushUpdate({ buses: newBuses });
  };

  const addUser = (userData: Omit<User, 'id' | 'joinedAt'>) => {
    const existing = users.find(u => u.name.toLowerCase() === userData.name.toLowerCase());
    if (existing) return;

    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      joinedAt: new Date().toISOString(),
    };
    const newUsers = [...users, newUser];
    setUsers(newUsers);
    pushUpdate({ users: newUsers });
  };

  const deleteUser = (userId: string) => {
    if (currentUser?.role !== 'ADMIN') return;
    const newUsers = users.filter(u => u.id !== userId);
    setUsers(newUsers);
    pushUpdate({ users: newUsers });
  };

  const login = (name: string): User | null => {
    const user = users.find(u => u.name.trim().toLowerCase() === name.trim().toLowerCase());
    if (user) {
      setCurrentUser(user);
      return user;
    }
    return null;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const updateAdminCredentials = (name: string, pass: string) => {
    if (currentUser?.role !== 'ADMIN') return;
    
    const newCreds = { name, password: pass };
    setAdminCredentials(newCreds);
    
    const newUsers = users.map(u => u.role === 'ADMIN' ? { ...u, name } : u);
    setUsers(newUsers);

    if (currentUser?.role === 'ADMIN') setCurrentUser(prev => prev ? { ...prev, name } : null);

    pushUpdate({ adminCredentials: newCreds, users: newUsers });
  };

  return (
    <SystemContext.Provider value={{ 
      buses, users, currentUser, adminCredentials,
      addBus, updateBusStatus, addStopToBus,
      addUser, deleteUser, deleteBus, login, logout, updateAdminCredentials
    }}>
      {children}
    </SystemContext.Provider>
  );
};

export const useSystem = () => {
  const context = useContext(SystemContext);
  if (!context) throw new Error('useSystem must be used within a SystemProvider');
  return context;
};